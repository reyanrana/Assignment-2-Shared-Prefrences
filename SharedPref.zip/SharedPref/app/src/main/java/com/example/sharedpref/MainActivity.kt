package com.example.sharedpref

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        bottomNavigation.setOnItemSelectedListener { item ->
            var selectedFragment: Fragment? = null
            when (item.itemId) {
                R.id.navigation_user_settings -> selectedFragment = UserSettingsFragment()
                R.id.navigation_profile_view -> selectedFragment = ProfileViewFragment()
            }
            if (selectedFragment != null) {
                replaceFragment(selectedFragment)
            }
            true
        }

        // Load the default fragment
        if (savedInstanceState == null) {
            replaceFragment(UserSettingsFragment())
            bottomNavigation.selectedItemId = R.id.navigation_user_settings
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}