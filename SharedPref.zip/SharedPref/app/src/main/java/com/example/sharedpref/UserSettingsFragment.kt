package com.example.sharedpref

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText

class UserSettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_user_settings, container, false)

        val etUsername = view.findViewById<TextInputEditText>(R.id.et_username)
        val etEmail = view.findViewById<TextInputEditText>(R.id.et_email)
        val etPassword = view.findViewById<TextInputEditText>(R.id.et_password)
        val switchNotifications = view.findViewById<SwitchMaterial>(R.id.switch_notifications)
        val rgTheme = view.findViewById<RadioGroup>(R.id.rg_theme)
        val btnSave = view.findViewById<Button>(R.id.btn_save)

        btnSave.setOnClickListener {
            val username = etUsername.text.toString()
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            val notificationsEnabled = switchNotifications.isChecked
            val selectedTheme = when (rgTheme.checkedRadioButtonId) {
                R.id.rb_light -> "Light"
                R.id.rb_dark -> "Dark"
                else -> "Light"
            }

            if (username.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                val sharedPref = requireActivity().getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
                with(sharedPref.edit()) {
                    putString("username", username)
                    putString("email", email)
                    putString("password", password)
                    putBoolean("notifications", notificationsEnabled)
                    putString("theme", selectedTheme)
                    apply()
                }
                Toast.makeText(requireContext(), "Preferences saved", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
}