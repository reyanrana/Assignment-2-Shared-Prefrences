package com.example.sharedpref

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class ProfileViewFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile_view, container, false)

        val tvUsername = view.findViewById<TextView>(R.id.tv_username)
        val tvEmail = view.findViewById<TextView>(R.id.tv_email)
        val tvNotifications = view.findViewById<TextView>(R.id.tv_notifications)
        val tvTheme = view.findViewById<TextView>(R.id.tv_theme)

        val sharedPref = requireActivity().getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val username = sharedPref.getString("username", "N/A")
        val email = sharedPref.getString("email", "N/A")
        val notificationsEnabled = sharedPref.getBoolean("notifications", false)
        val theme = sharedPref.getString("theme", "Light")

        tvUsername.text = "Username: $username"
        tvEmail.text = "Email: $email"
        tvNotifications.text = "Notifications: ${if (notificationsEnabled) "Enabled" else "Disabled"}"
        tvTheme.text = "Theme: $theme"

        return view
    }
}